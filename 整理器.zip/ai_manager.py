"""
AI Tools Manager - 智能版
自动识别启动脚本和参数，在实例目录直接执行
"""

import sys
import os

# 设置UTF-8编码
if sys.platform == 'win32':
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
    if sys.stderr.encoding != 'utf-8':
        sys.stderr.reconfigure(encoding='utf-8')
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import json
import subprocess
import psutil
import webbrowser
import re
from pathlib import Path
from datetime import datetime
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QFont


def find_python_executable(path: Path):
    """智能查找Python可执行文件，支持实例目录和父目录，返回绝对路径确保稳定性"""
    # 常见的内置Python路径 - 按优先级排序
    python_candidates = [
        # 自定义环境名称（优先级最高）
        'wzf312/python.exe',
        # Python环境
        'python_embeded/python.exe',
        'python_embedded/python.exe',
        'python/python.exe',
        'python310/python.exe',
        'python311/python.exe',
        'python312/python.exe',
        # 虚拟环境
        'venv/Scripts/python.exe',
        'env/Scripts/python.exe',
        '.venv/Scripts/python.exe',
        # Conda环境
        'conda/python.exe',
        'miniconda/python.exe',
        # 其他可能的位置
        'Scripts/python.exe',
    ]
    
    # 首先在实例目录中查找
    for candidate in python_candidates:
        python_path = path / candidate
        if python_path.exists():
            # 返回绝对路径，确保启动稳定性
            return str(python_path.absolute())
    
    # 🔥 新增：在父目录中查找（整合包结构）
    # 例如: Wan22 Ultra GGUF版本/python_embeded/python.exe
    #       Wan22 Ultra GGUF版本/ComfyUI/...
    parent_path = path.parent
    if parent_path and parent_path.exists():
        for candidate in python_candidates:
            python_path = parent_path / candidate
            if python_path.exists():
                return str(python_path.absolute())
    
    # 如果没有找到内置Python，返回 'python' 使用系统Python
    return 'python'


def find_launch_script(path: Path):
    """智能查找启动脚本"""
    # 优先级列表
    script_candidates = [
        'run.bat', 'run_gpu.bat', 'run_nvidia_gpu.bat',
        '启动.bat', '运行.bat', 
        'webui-user.bat', 'webui.bat',
        'start.bat', 'launch.bat',
        'main.py', 'webui.py', 'launch.py'
    ]
    
    for script in script_candidates:
        script_path = path / script
        if script_path.exists():
            return script
    
    return None


def extract_port_from_script(script_path: Path):
    """从脚本中提取端口号"""
    try:
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
            # 查找 --port 参数
            port_match = re.search(r'--port\s+(\d+)', content)
            if port_match:
                return int(port_match.group(1))
            
            # 查找 --listen 后面的端口
            listen_match = re.search(r'--listen\s+.*?:(\d+)', content)
            if listen_match:
                return int(listen_match.group(1))
                
    except:
        pass
    
    return None


def extract_args_from_script(script_path: Path):
    """从脚本中提取启动参数"""
    try:
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
            # 查找 python main.py 或 python webui.py 后面的参数
            py_match = re.search(r'python\s+(?:main|webui|launch)\.py\s+(.+?)(?:\n|$)', content, re.IGNORECASE)
            if py_match:
                args = py_match.group(1).strip()
                # 移除一些不需要的参数
                args = re.sub(r'--port\s+\d+', '', args)
                return args.strip()
    except:
        pass
    
    return ''


class StatsWorker(QThread):
    """统计信息工作线程"""
    finished = pyqtSignal(dict)
    
    def __init__(self, instance):
        super().__init__()
        self.instance = instance
        self._is_running = True
    
    def run(self):
        """在后台线程中计算统计信息"""
        path = Path(self.instance['path'])
        stats = {
            'models': 0,
            'loras': 0,
            'outputs': 0,
            'custom_nodes': 0,
            'disk_usage': 0
        }
        
        try:
            # 确定路径
            if self.instance['type'] == 'ComfyUI':
                models_path = path / 'models' / 'checkpoints'
                loras_path = path / 'models' / 'loras'
                output_path = path / 'output'
                nodes_path = path / 'custom_nodes'
            else:  # WebUI
                models_path = path / 'models' / 'Stable-diffusion'
                loras_path = path / 'models' / 'Lora'
                output_path = path / 'outputs'
                nodes_path = path / 'extensions'
            
            # 快速统计
            if self._is_running and models_path.exists():
                stats['models'] = sum(1 for f in models_path.iterdir() 
                                     if f.is_file() and f.suffix in ['.safetensors', '.ckpt', '.pt'])
            
            if self._is_running and loras_path.exists():
                stats['loras'] = sum(1 for f in loras_path.iterdir() 
                                    if f.is_file() and f.suffix == '.safetensors')
            
            if self._is_running and output_path.exists():
                count = 0
                for subdir in list(output_path.iterdir())[:10]:
                    if subdir.is_dir():
                        count += sum(1 for f in subdir.iterdir() 
                                   if f.is_file() and f.suffix in ['.png', '.jpg', '.jpeg'])
                stats['outputs'] = count
            
            if self._is_running and nodes_path.exists():
                stats['custom_nodes'] = sum(1 for d in nodes_path.iterdir() if d.is_dir())
            
            # 快速估算磁盘占用
            if self._is_running:
                total_size = 0
                check_paths = [models_path, loras_path]
                for check_path in check_paths:
                    if check_path.exists():
                        for item in list(check_path.iterdir())[:50]:
                            if item.is_file():
                                try:
                                    total_size += item.stat().st_size
                                except:
                                    pass
                stats['disk_usage'] = total_size / (1024**3)
                
        except Exception as e:
            print(f"统计信息获取失败: {e}")
        
        if self._is_running:
            self.finished.emit(stats)
    
    def stop(self):
        """停止线程"""
        self._is_running = False


class InstanceScanner(QThread):
    """智能扫描实例"""
    found = pyqtSignal(dict)
    finished_scan = pyqtSignal(list)
    progress = pyqtSignal(str)
    
    def __init__(self, search_paths=None):
        super().__init__()
        self.search_paths = search_paths or []
        self.instances = []
        self._is_running = True
        
    def run(self):
        """执行扫描"""
        common_paths = [
            Path.home() / "Desktop",
            Path.home() / "Documents",
            Path("D:/"),
            Path("E:/"),
            Path("F:/"),
            Path("G:/"),
        ]
        
        search_dirs = self.search_paths if self.search_paths else common_paths
        
        for base_path in search_dirs:
            if not self._is_running:
                break
            if not base_path.exists():
                continue
            self.progress.emit(f"正在扫描: {base_path}")
            self.scan_directory(base_path, depth=0, max_depth=3)
        
        if self._is_running:
            self.finished_scan.emit(self.instances)
    
    def scan_directory(self, path: Path, depth: int, max_depth: int):
        """递归扫描目录"""
        if not self._is_running or depth > max_depth:
            return
        
        try:
            for item in list(path.iterdir())[:100]:
                if not self._is_running:
                    break
                    
                if item.is_dir():
                    if self.is_comfyui(item):
                        instance = self.create_comfyui_instance(item)
                        self.instances.append(instance)
                        self.found.emit(instance)
                    elif self.is_webui(item):
                        instance = self.create_webui_instance(item)
                        self.instances.append(instance)
                        self.found.emit(instance)
                    else:
                        self.scan_directory(item, depth + 1, max_depth)
        except (PermissionError, OSError):
            pass
        except Exception as e:
            print(f"扫描错误: {e}")
    
    def is_comfyui(self, path: Path) -> bool:
        """判断是否是 ComfyUI 实例"""
        required_items = ['comfy', 'custom_nodes']
        has_main = (path / 'main.py').exists()
        has_required = all((path / name).exists() for name in required_items)
        return has_main and has_required
    
    def is_webui(self, path: Path) -> bool:
        """判断是否是 WebUI 实例"""
        has_webui = (path / 'webui.py').exists()
        has_modules = (path / 'modules').exists()
        has_extensions = (path / 'extensions').exists()
        return has_webui and (has_modules or has_extensions)
    
    def create_comfyui_instance(self, path: Path) -> dict:
        """创建 ComfyUI 实例配置"""
        # 智能查找启动脚本
        launch_script = find_launch_script(path)
        if not launch_script:
            launch_script = 'main.py'
        
        # 提取端口和参数
        port = 8188
        args = ''
        
        if launch_script.endswith('.bat'):
            script_path = path / launch_script
            detected_port = extract_port_from_script(script_path)
            if detected_port:
                port = detected_port
            args = extract_args_from_script(script_path)
        
        return {
            'type': 'ComfyUI',
            'name': path.name,
            'path': str(path),
            'main_script': launch_script,
            'port': port,
            'args': args,
            'description': f'自动扫描发现 - {datetime.now().strftime("%Y-%m-%d %H:%M")}'
        }
    
    def create_webui_instance(self, path: Path) -> dict:
        """创建 WebUI 实例配置"""
        # 智能查找启动脚本
        launch_script = find_launch_script(path)
        if not launch_script:
            launch_script = 'webui-user.bat' if (path / 'webui-user.bat').exists() else 'launch.py'
        
        # 提取端口和参数
        port = 7860
        args = ''
        
        if launch_script.endswith('.bat'):
            script_path = path / launch_script
            detected_port = extract_port_from_script(script_path)
            if detected_port:
                port = detected_port
            args = extract_args_from_script(script_path)
        
        return {
            'type': 'WebUI',
            'name': path.name,
            'path': str(path),
            'main_script': launch_script,
            'port': port,
            'args': args,
            'description': f'自动扫描发现 - {datetime.now().strftime("%Y-%m-%d %H:%M")}'
        }
    
    def stop(self):
        """停止扫描"""
        self._is_running = False


class QuickEditDialog(QDialog):
    """快速编辑对话框"""
    
    def __init__(self, instance, parent=None):
        super().__init__(parent)
        self.instance = instance
        self.instance_path = Path(instance['path'])
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle(f"快速编辑 - {self.instance['name']}")
        self.setMinimumWidth(550)
        
        layout = QFormLayout()
        
        # 启动脚本
        script_layout = QHBoxLayout()
        self.script_edit = QLineEdit()
        self.script_edit.setText(self.instance.get('main_script', ''))
        self.script_edit.setPlaceholderText("例如: run.bat 或 main.py 或 start.exe")
        
        browse_script_btn = QPushButton("浏览...")
        browse_script_btn.clicked.connect(self.browse_script)
        
        script_layout.addWidget(self.script_edit)
        script_layout.addWidget(browse_script_btn)
        
        layout.addRow("启动脚本:", script_layout)
        
        # 脚本类型提示
        script_hint = QLabel("💡 支持: .bat / .cmd / .exe / .py 文件")
        script_hint.setStyleSheet("color: gray; font-size: 9pt;")
        layout.addRow("", script_hint)
        
        # Python路径
        python_layout = QHBoxLayout()
        self.python_edit = QLineEdit()
        
        # 自动检测当前使用的Python
        current_python = self.instance.get('python_path')
        if not current_python:
            current_python = find_python_executable(self.instance_path)
        
        self.python_edit.setText(current_python)
        self.python_edit.setPlaceholderText("例如: python 或 python_embeded/python.exe")
        
        # 自动检测按钮
        detect_btn = QPushButton("🔍 自动检测")
        detect_btn.clicked.connect(self.auto_detect_python)
        
        # 浏览按钮
        browse_btn = QPushButton("浏览...")
        browse_btn.clicked.connect(self.browse_python)
        
        python_layout.addWidget(self.python_edit)
        python_layout.addWidget(detect_btn)
        python_layout.addWidget(browse_btn)
        
        layout.addRow("Python路径:", python_layout)
        
        # Python提示信息
        python_hint = QLabel("💡 留空或填 'python' 使用系统Python\n仅对 .py 脚本有效，.bat/.exe 会忽略此设置")
        python_hint.setStyleSheet("color: gray; font-size: 9pt;")
        python_hint.setWordWrap(True)
        layout.addRow("", python_hint)
        
        # 端口
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.port_spin.setValue(self.instance.get('port', 8188))
        layout.addRow("端口:", self.port_spin)
        
        # 启动参数
        self.args_edit = QLineEdit()
        self.args_edit.setText(self.instance.get('args', ''))
        self.args_edit.setPlaceholderText("例如: --highvram --preview-method auto")
        layout.addRow("启动参数:", self.args_edit)
        
        # 参数提示
        args_hint = QLabel("💡 参数仅对 .py 脚本有效\n.bat/.exe 文件的参数需要在脚本内部配置")
        args_hint.setStyleSheet("color: gray; font-size: 9pt;")
        args_hint.setWordWrap(True)
        layout.addRow("", args_hint)
        
        # 按钮
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("保存")
        save_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        
        layout.addRow("", btn_layout)
        self.setLayout(layout)
    
    def browse_script(self):
        """浏览选择启动脚本"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择启动脚本",
            str(self.instance_path),
            "启动脚本 (*.bat *.cmd *.exe *.py);;批处理文件 (*.bat *.cmd);;可执行文件 (*.exe);;Python脚本 (*.py);;所有文件 (*.*)"
        )
        
        if file_path:
            # 转换为相对路径
            try:
                rel_path = Path(file_path).relative_to(self.instance_path)
                self.script_edit.setText(str(rel_path).replace('\\', '/'))
            except ValueError:
                # 如果不在实例目录下，使用绝对路径
                self.script_edit.setText(file_path)
    
    def auto_detect_python(self):
        """自动检测Python路径"""
        python_path = find_python_executable(self.instance_path)
        self.python_edit.setText(python_path)
        
        if python_path == 'python':
            QMessageBox.information(self, "检测结果", "未找到内置Python，将使用系统Python")
        else:
            QMessageBox.information(self, "检测结果", f"找到内置Python:\n{python_path}")
    
    def browse_python(self):
        """浏览选择Python可执行文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择 Python 可执行文件",
            str(self.instance_path),
            "可执行文件 (*.exe);;所有文件 (*.*)"
        )
        
        if file_path:
            # 尝试转换为相对路径
            try:
                rel_path = Path(file_path).relative_to(self.instance_path)
                self.python_edit.setText(str(rel_path).replace('\\', '/'))
            except ValueError:
                # 如果不在实例目录下，使用绝对路径
                self.python_edit.setText(file_path)
    
    def get_data(self):
        """获取修改后的数据"""
        python_path = self.python_edit.text().strip()
        
        # 如果为空或者是 'python'，不保存python_path
        if not python_path or python_path == 'python':
            python_path = None
        
        return {
            'main_script': self.script_edit.text().strip(),
            'python_path': python_path,
            'port': self.port_spin.value(),
            'args': self.args_edit.text().strip()
        }


class AddInstanceDialog(QDialog):
    """添加/编辑实例对话框"""
    
    def __init__(self, parent=None, instance_data=None):
        super().__init__(parent)
        self.instance_data = instance_data
        self.init_ui()
        
        if instance_data:
            self.load_data(instance_data)
    
    def init_ui(self):
        self.setWindowTitle("添加/编辑实例")
        self.setMinimumWidth(550)
        
        layout = QFormLayout()
        
        # 实例类型
        self.type_combo = QComboBox()
        self.type_combo.addItems(['ComfyUI', 'WebUI'])
        self.type_combo.currentTextChanged.connect(self.on_type_changed)
        layout.addRow("类型:", self.type_combo)
        
        # 实例名称
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("例如: SDXL生图专用")
        layout.addRow("名称:", self.name_edit)
        
        # 实例路径
        path_layout = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("选择实例根目录")
        self.path_edit.textChanged.connect(self.on_path_changed)
        browse_btn = QPushButton("浏览...")
        browse_btn.clicked.connect(self.browse_path)
        path_layout.addWidget(self.path_edit)
        path_layout.addWidget(browse_btn)
        layout.addRow("路径:", path_layout)
        
        # 描述
        self.desc_edit = QTextEdit()
        self.desc_edit.setPlaceholderText("可选的描述信息")
        self.desc_edit.setMaximumHeight(60)
        layout.addRow("描述:", self.desc_edit)
        
        # 启动脚本
        script_layout = QHBoxLayout()
        self.script_edit = QLineEdit()
        self.script_edit.setText("main.py")
        self.script_edit.setPlaceholderText("例如: run.bat 或 main.py 或 start.exe")
        
        browse_script_btn = QPushButton("浏览...")
        browse_script_btn.clicked.connect(self.browse_script)
        
        script_layout.addWidget(self.script_edit)
        script_layout.addWidget(browse_script_btn)
        
        layout.addRow("启动脚本:", script_layout)
        
        # Python路径
        python_layout = QHBoxLayout()
        self.python_edit = QLineEdit()
        self.python_edit.setPlaceholderText("留空自动检测，或填 python_embeded/python.exe")
        
        detect_py_btn = QPushButton("🔍 自动检测")
        detect_py_btn.clicked.connect(self.auto_detect_python)
        
        browse_py_btn = QPushButton("浏览...")
        browse_py_btn.clicked.connect(self.browse_python)
        
        python_layout.addWidget(self.python_edit)
        python_layout.addWidget(detect_py_btn)
        python_layout.addWidget(browse_py_btn)
        
        layout.addRow("Python路径:", python_layout)
        
        # 端口号
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.port_spin.setValue(8188)
        layout.addRow("默认端口:", self.port_spin)
        
        # 启动参数
        self.args_edit = QLineEdit()
        self.args_edit.setPlaceholderText("例如: --highvram --preview-method auto")
        layout.addRow("启动参数:", self.args_edit)
        
        # 按钮
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("保存")
        save_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        
        layout.addRow("", btn_layout)
        self.setLayout(layout)
    
    def on_type_changed(self, instance_type):
        """类型改变时更新默认值"""
        if instance_type == 'ComfyUI':
            self.script_edit.setText('main.py')
            self.port_spin.setValue(8188)
        else:
            self.script_edit.setText('webui-user.bat')
            self.port_spin.setValue(7860)
    
    def on_path_changed(self, path_text):
        """路径改变时自动检测"""
        if not path_text:
            return
        
        path = Path(path_text)
        if not path.exists():
            return
        
        # 检测类型
        if (path / 'main.py').exists() and (path / 'comfy').exists():
            self.type_combo.setCurrentText('ComfyUI')
            if not self.name_edit.text():
                self.name_edit.setText(path.name)
            
            # 智能查找启动脚本
            script = find_launch_script(path)
            if script:
                self.script_edit.setText(script)
                
                # 如果是批处理文件，提取参数
                if script.endswith('.bat'):
                    script_path = path / script
                    port = extract_port_from_script(script_path)
                    if port:
                        self.port_spin.setValue(port)
                    
                    args = extract_args_from_script(script_path)
                    if args:
                        self.args_edit.setText(args)
                        
        elif (path / 'webui.py').exists():
            self.type_combo.setCurrentText('WebUI')
            if not self.name_edit.text():
                self.name_edit.setText(path.name)
            
            # 智能查找启动脚本
            script = find_launch_script(path)
            if script:
                self.script_edit.setText(script)
                
                # 如果是批处理文件，提取参数
                if script.endswith('.bat'):
                    script_path = path / script
                    port = extract_port_from_script(script_path)
                    if port:
                        self.port_spin.setValue(port)
                    
                    args = extract_args_from_script(script_path)
                    if args:
                        self.args_edit.setText(args)
    
    def browse_path(self):
        """浏览文件夹"""
        path = QFileDialog.getExistingDirectory(self, "选择实例目录")
        if path:
            self.path_edit.setText(path)
    
    def browse_script(self):
        """浏览选择启动脚本"""
        path_text = self.path_edit.text()
        if not path_text:
            QMessageBox.warning(self, "提示", "请先选择实例路径")
            return
        
        instance_path = Path(path_text)
        
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择启动脚本",
            str(instance_path),
            "启动脚本 (*.bat *.cmd *.exe *.py);;批处理文件 (*.bat *.cmd);;可执行文件 (*.exe);;Python脚本 (*.py);;所有文件 (*.*)"
        )
        
        if file_path:
            # 转换为相对路径
            try:
                rel_path = Path(file_path).relative_to(instance_path)
                self.script_edit.setText(str(rel_path).replace('\\', '/'))
            except ValueError:
                # 如果不在实例目录下，使用绝对路径
                self.script_edit.setText(file_path)
    
    def auto_detect_python(self):
        """自动检测Python路径"""
        path_text = self.path_edit.text()
        if not path_text:
            QMessageBox.warning(self, "提示", "请先选择实例路径")
            return
        
        path = Path(path_text)
        if not path.exists():
            QMessageBox.warning(self, "提示", "实例路径不存在")
            return
        
        python_path = find_python_executable(path)
        self.python_edit.setText(python_path)
        
        if python_path == 'python':
            QMessageBox.information(self, "检测结果", "未找到内置Python，将使用系统Python")
        else:
            QMessageBox.information(self, "检测结果", f"找到内置Python:\n{python_path}")
    
    def browse_python(self):
        """浏览选择Python可执行文件"""
        path_text = self.path_edit.text()
        if not path_text:
            QMessageBox.warning(self, "提示", "请先选择实例路径")
            return
        
        instance_path = Path(path_text)
        
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择 Python 可执行文件",
            str(instance_path),
            "可执行文件 (*.exe);;所有文件 (*.*)"
        )
        
        if file_path:
            # 尝试转换为相对路径
            try:
                rel_path = Path(file_path).relative_to(instance_path)
                self.python_edit.setText(str(rel_path).replace('\\', '/'))
            except ValueError:
                # 如果不在实例目录下，使用绝对路径
                self.python_edit.setText(file_path)
    
    def load_data(self, data):
        """加载实例数据"""
        self.type_combo.setCurrentText(data.get('type', 'ComfyUI'))
        self.name_edit.setText(data.get('name', ''))
        self.path_edit.setText(data.get('path', ''))
        self.desc_edit.setPlainText(data.get('description', ''))
        self.script_edit.setText(data.get('main_script', 'main.py'))
        self.python_edit.setText(data.get('python_path', ''))
        self.port_spin.setValue(data.get('port', 8188))
        self.args_edit.setText(data.get('args', ''))
    
    def get_data(self):
        """获取实例数据"""
        python_path = self.python_edit.text().strip()
        
        # 如果为空或者是 'python'，不保存python_path
        if not python_path or python_path == 'python':
            python_path = None
        
        return {
            'type': self.type_combo.currentText(),
            'name': self.name_edit.text().strip(),
            'path': self.path_edit.text().strip(),
            'description': self.desc_edit.toPlainText().strip(),
            'main_script': self.script_edit.text().strip(),
            'python_path': python_path,
            'port': self.port_spin.value(),
            'args': self.args_edit.text().strip(),
            'created_at': datetime.now().isoformat(),
            'last_used': None,
            'process_id': None
        }


class InstanceManager:
    """实例管理器"""
    
    def __init__(self, config_file='ai_instances.json'):
        self.config_file = config_file
        self.instances = []
        self.processes = {}
        self.settings = {
            'auto_open_browser': True,  # 🔥 新增：自动打开浏览器设置
            'browser_delay': 3           # 🔥 新增：浏览器打开延迟（秒）
        }
        self.load_config()
    
    def load_config(self):
        """加载配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.instances = data.get('instances', [])
                    self.settings.update(data.get('settings', {}))
            except Exception as e:
                print(f"加载配置失败: {e}")
                self.instances = []
        else:
            self.instances = []
    
    def save_config(self):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'instances': self.instances,
                    'settings': self.settings
                }, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置失败: {e}")
            return False
    
    def add_instance(self, instance_data):
        """添加实例"""
        instance_data['id'] = self.generate_id()
        self.instances.append(instance_data)
        self.save_config()
        return instance_data['id']
    
    def update_instance(self, instance_id, instance_data):
        """更新实例"""
        for i, inst in enumerate(self.instances):
            if inst.get('id') == instance_id:
                instance_data['id'] = instance_id
                instance_data['created_at'] = inst.get('created_at')
                instance_data['last_used'] = inst.get('last_used')
                self.instances[i] = instance_data
                self.save_config()
                return True
        return False
    
    def quick_update(self, instance_id, updates):
        """快速更新实例的部分字段"""
        for inst in self.instances:
            if inst.get('id') == instance_id:
                inst.update(updates)
                self.save_config()
                return True
        return False
    
    def delete_instance(self, instance_id):
        """删除实例"""
        self.instances = [inst for inst in self.instances if inst.get('id') != instance_id]
        self.save_config()
    
    def get_instance(self, instance_id):
        """获取实例"""
        for inst in self.instances:
            if inst.get('id') == instance_id:
                return inst
        return None
    
    def generate_id(self):
        """生成唯一ID"""
        import uuid
        return str(uuid.uuid4())[:8]
    
    def start_instance(self, instance_id):
        """启动实例 - 直接在目录中执行启动脚本，确保使用正确的Python环境"""
        instance = self.get_instance(instance_id)
        if not instance:
            return False, "实例不存在"
        
        path = Path(instance['path'])
        if not path.exists():
            return False, "实例路径不存在"
        
        script = instance['main_script']
        script_path = path / script
        
        if not script_path.exists():
            return False, f"启动脚本不存在: {script}"
        
        # 检查端口
        port = instance.get('port', 8188)
        if self.is_port_in_use(port):
            return False, f"端口 {port} 已被占用"
        
        try:
            script_lower = script.lower()
            
            # 处理可执行文件 (.exe)
            if script_lower.endswith('.exe'):
                if sys.platform == 'win32':
                    process = subprocess.Popen(
                        [str(script_path)],
                        cwd=str(path)
                    )
                else:
                    return False, "EXE文件只能在 Windows 上运行"
            
            # 处理批处理文件 (.bat, .cmd)
            elif script_lower.endswith(('.bat', '.cmd')):
                if sys.platform == 'win32':
                    # 检查是否需要设置Python环境
                    python_exe = instance.get('python_path')
                    if not python_exe:
                        python_exe = find_python_executable(path)
                    
                    # 如果有内置Python，创建一个临时启动脚本确保使用正确的Python
                    if python_exe != 'python':
                        # 创建临时启动脚本，设置正确的Python环境
                        temp_bat = path / f"_temp_start_{port}.bat"
                        
                        # 读取原始bat文件
                        try:
                            with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
                                original_content = f.read()
                        except:
                            with open(script_path, 'r', encoding='gbk', errors='ignore') as f:
                                original_content = f.read()
                        
                        # 创建新的bat文件，设置PATH环境变量
                        python_dir = str(Path(python_exe).parent) if python_exe != 'python' else ''
                        
                        with open(temp_bat, 'w', encoding='utf-8') as f:
                            f.write('@echo off\n')
                            f.write('chcp 65001 >nul\n')
                            f.write(f'title {instance["name"]} - 端口 {port}\n')
                            f.write(f'cd /d "{path}"\n')
                            
                            # 如果有内置Python，优先添加到PATH
                            if python_dir:
                                # 转换为绝对路径
                                if not os.path.isabs(python_dir):
                                    python_dir = str(path / python_dir)
                                f.write(f'set PATH={python_dir};%PATH%\n')
                                f.write(f'echo 使用 Python: {python_dir}\\python.exe\n')
                                f.write(f'{python_dir}\\python.exe --version\n')
                            
                            f.write('echo.\n')
                            f.write('echo ========================================\n')
                            f.write(f'echo {instance["name"]}\n')
                            f.write(f'echo 端口: {port}\n')
                            f.write('echo ========================================\n')
                            f.write('echo.\n')
                            
                            # 调用原始bat文件
                            f.write(f'call "{script}"\n')
                            
                            f.write('echo.\n')
                            f.write('echo ========================================\n')
                            f.write('echo 程序已退出，按任意键关闭窗口...\n')
                            f.write('pause >nul\n')
                        
                        # 启动临时脚本
                        process = subprocess.Popen(
                            ['cmd', '/c', 'start', 'cmd', '/k', str(temp_bat)],
                            cwd=str(path),
                            shell=False
                        )
                    else:
                        # 没有内置Python，直接执行原始bat
                        process = subprocess.Popen(
                            ['cmd', '/c', 'start', 'cmd', '/k', script],
                            cwd=str(path),
                            shell=False
                        )
                else:
                    return False, "批处理文件只能在 Windows 上运行"
            
            # 处理Python脚本 (.py)
            else:
                # 优先使用用户指定的Python路径
                python_exe = instance.get('python_path')
                
                if not python_exe:
                    # 如果没有指定，自动检测
                    python_exe = find_python_executable(path)
                else:
                    # 如果是相对路径，转换为绝对路径
                    if not os.path.isabs(python_exe):
                        python_exe = str((path / python_exe).absolute())
                
                # 验证Python是否存在
                if python_exe != 'python' and not Path(python_exe).exists():
                    return False, f"指定的Python不存在: {python_exe}"
                
                python_info = "系统Python"
                if python_exe != 'python':
                    python_info = f"指定Python ({python_exe})"
                
                args = instance.get('args', '').split()
                if instance['type'] == 'ComfyUI':
                    cmd = [python_exe, script, '--listen', '--port', str(port)] + args
                else:
                    cmd = [python_exe, script] + args
                    if '--port' not in args:
                        cmd.extend(['--port', str(port)])
                
                # 🔥 关键：创建隔离的环境变量，防止系统Python干扰
                env = os.environ.copy()
                env['PYTHONNOUSERSITE'] = '1'  # 禁止加载用户site-packages (C:\Users\...\AppData\Roaming\Python)
                env['PYTHONPATH'] = ''         # 清空PYTHONPATH，避免路径污染
                
                # 如果使用内置Python，清理PATH确保不加载系统Python的DLL
                if python_exe != 'python':
                    python_dir = str(Path(python_exe).parent)
                    # 将内置Python目录放在PATH最前面
                    env['PATH'] = f"{python_dir};{env.get('PATH', '')}"
                
                if sys.platform == 'win32':
                    process = subprocess.Popen(
                        cmd,
                        cwd=str(path),
                        env=env,  # 🔥 使用隔离的环境变量
                        creationflags=subprocess.CREATE_NEW_CONSOLE
                    )
                else:
                    process = subprocess.Popen(
                        cmd, 
                        cwd=str(path),
                        env=env  # 🔥 使用隔离的环境变量
                    )
            
            # 等待一下确保进程启动
            import time
            time.sleep(0.5)
            
            self.processes[instance_id] = process
            instance['process_id'] = process.pid
            instance['last_used'] = datetime.now().isoformat()
            self.save_config()
            
            msg = f"实例已启动 (PID: {process.pid}, 端口: {port})"
            if script_lower.endswith('.py'):
                msg += f"\nPython: {python_info}"
            elif script_lower.endswith(('.bat', '.cmd')):
                python_exe = instance.get('python_path')
                if not python_exe:
                    python_exe = find_python_executable(path)
                if python_exe != 'python':
                    msg += f"\n已设置Python环境: {python_exe}"
            
            # 🔥 自动打开浏览器（如果启用）
            if self.settings.get('auto_open_browser', True):
                # 等待服务启动
                delay = self.settings.get('browser_delay', 3)
                time.sleep(delay)
                url = f"http://127.0.0.1:{port}"
                try:
                    webbrowser.open(url)
                    msg += f"\n已自动打开浏览器: {url}"
                except:
                    msg += f"\n浏览器打开失败，请手动访问: {url}"
            
            return True, msg
        except Exception as e:
            return False, f"启动失败: {str(e)}"
    
    def stop_instance(self, instance_id):
        """停止实例"""
        if instance_id not in self.processes:
            return False, "实例未运行"
        
        process = self.processes[instance_id]
        try:
            parent = psutil.Process(process.pid)
            for child in parent.children(recursive=True):
                child.terminate()
            parent.terminate()
            
            process.wait(timeout=5)
            del self.processes[instance_id]
            
            instance = self.get_instance(instance_id)
            if instance:
                instance['process_id'] = None
                self.save_config()
            
            return True, "实例已停止"
        except psutil.NoSuchProcess:
            del self.processes[instance_id]
            return True, "实例已停止"
        except Exception as e:
            return False, f"停止失败: {str(e)}"
    
    def is_running(self, instance_id):
        """检查实例是否运行中"""
        if instance_id not in self.processes:
            return False
        
        process = self.processes[instance_id]
        try:
            return process.poll() is None
        except:
            return False
    
    def is_port_in_use(self, port):
        """检查端口是否被占用"""
        try:
            for conn in psutil.net_connections():
                if conn.laddr.port == port:
                    return True
        except:
            pass
        return False


class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.manager = InstanceManager()
        self.current_instance_id = None
        self.stats_worker = None
        self.scanner = None
        self.init_ui()
        self.refresh_instance_list()
        
        # 定时器
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_status)
        self.timer.start(3000)
    
    def init_ui(self):
        self.setWindowTitle("AI Tools Manager - 智能版")
        self.setGeometry(100, 100, 1200, 700)
        
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 顶部工具栏
        toolbar = self.create_toolbar()
        main_layout.addLayout(toolbar)
        
        # 分割器
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧实例列表
        left_panel = self.create_left_panel()
        splitter.addWidget(left_panel)
        
        # 右侧详情面板
        right_panel = self.create_right_panel()
        splitter.addWidget(right_panel)
        
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        
        main_layout.addWidget(splitter)
        
        # 状态栏
        self.statusBar().showMessage("就绪 - 智能识别启动脚本")
    
    def create_toolbar(self):
        """创建工具栏"""
        layout = QHBoxLayout()
        
        add_btn = QPushButton("➕ 添加实例")
        add_btn.clicked.connect(self.add_instance)
        
        scan_btn = QPushButton("🔍 智能扫描")
        scan_btn.clicked.connect(self.scan_instances)
        
        refresh_btn = QPushButton("🔄 刷新")
        refresh_btn.clicked.connect(self.refresh_instance_list)
        
        settings_btn = QPushButton("⚙️ 设置")
        settings_btn.clicked.connect(self.show_settings)
        
        layout.addWidget(add_btn)
        layout.addWidget(scan_btn)
        layout.addWidget(refresh_btn)
        layout.addWidget(settings_btn)
        layout.addStretch()
        
        return layout
    
    def create_left_panel(self):
        """创建左侧面板"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        label = QLabel("实例列表")
        font = QFont()
        font.setBold(True)
        font.setPointSize(10)
        label.setFont(font)
        
        self.instance_list = QListWidget()
        self.instance_list.currentItemChanged.connect(self.on_instance_selected)
        
        layout.addWidget(label)
        layout.addWidget(self.instance_list)
        
        return widget
    
    def create_right_panel(self):
        """创建右侧面板"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 提示标签
        self.empty_label = QLabel("← 请从左侧选择一个实例")
        self.empty_label.setAlignment(Qt.AlignCenter)
        font = QFont()
        font.setPointSize(12)
        self.empty_label.setFont(font)
        self.empty_label.setStyleSheet("color: gray;")
        
        # 详情容器
        self.detail_container = QWidget()
        detail_layout = QVBoxLayout(self.detail_container)
        
        # 实例信息
        info_group = QGroupBox("实例信息")
        info_layout = QFormLayout()
        
        self.info_name = QLabel()
        self.info_type = QLabel()
        self.info_path = QLabel()
        self.info_path.setWordWrap(True)
        self.info_script = QLabel()
        self.info_python = QLabel()
        self.info_status = QLabel()
        self.info_port = QLabel()
        
        info_layout.addRow("名称:", self.info_name)
        info_layout.addRow("类型:", self.info_type)
        info_layout.addRow("路径:", self.info_path)
        info_layout.addRow("启动脚本:", self.info_script)
        info_layout.addRow("Python:", self.info_python)
        info_layout.addRow("状态:", self.info_status)
        info_layout.addRow("端口:", self.info_port)
        
        info_group.setLayout(info_layout)
        detail_layout.addWidget(info_group)
        
        # 控制按钮
        control_group = QGroupBox("控制")
        control_layout = QGridLayout()
        
        self.start_btn = QPushButton("🚀 启动")
        self.start_btn.clicked.connect(self.start_instance)
        
        self.stop_btn = QPushButton("⏹ 停止")
        self.stop_btn.clicked.connect(self.stop_instance)
        self.stop_btn.setEnabled(False)
        
        self.browser_btn = QPushButton("🌐 打开浏览器")
        self.browser_btn.clicked.connect(self.open_browser)
        
        self.quick_edit_btn = QPushButton("⚡ 快速编辑")
        self.quick_edit_btn.clicked.connect(self.quick_edit)
        
        control_layout.addWidget(self.start_btn, 0, 0)
        control_layout.addWidget(self.stop_btn, 0, 1)
        control_layout.addWidget(self.browser_btn, 1, 0)
        control_layout.addWidget(self.quick_edit_btn, 1, 1)
        
        control_group.setLayout(control_layout)
        detail_layout.addWidget(control_group)
        
        # 快速访问
        access_group = QGroupBox("快速访问")
        access_layout = QGridLayout()
        
        self.output_btn = QPushButton("📁 输出")
        self.output_btn.clicked.connect(lambda: self.open_folder('output'))
        self.lora_btn = QPushButton("📁 LoRA")
        self.lora_btn.clicked.connect(lambda: self.open_folder('lora'))
        self.model_btn = QPushButton("📁 模型")
        self.model_btn.clicked.connect(lambda: self.open_folder('model'))
        self.node_btn = QPushButton("📁 插件")
        self.node_btn.clicked.connect(lambda: self.open_folder('node'))
        self.root_btn = QPushButton("📁 根目录")
        self.root_btn.clicked.connect(lambda: self.open_folder('root'))
        
        access_layout.addWidget(self.output_btn, 0, 0)
        access_layout.addWidget(self.lora_btn, 0, 1)
        access_layout.addWidget(self.model_btn, 1, 0)
        access_layout.addWidget(self.node_btn, 1, 1)
        access_layout.addWidget(self.root_btn, 2, 0, 1, 2)
        
        access_group.setLayout(access_layout)
        detail_layout.addWidget(access_group)
        
        # 统计信息
        stats_group = QGroupBox("统计信息")
        stats_layout = QFormLayout()
        
        self.stats_models = QLabel()
        self.stats_loras = QLabel()
        self.stats_outputs = QLabel()
        self.stats_nodes = QLabel()
        self.stats_disk = QLabel()
        
        stats_layout.addRow("模型:", self.stats_models)
        stats_layout.addRow("LoRA:", self.stats_loras)
        stats_layout.addRow("输出:", self.stats_outputs)
        stats_layout.addRow("插件:", self.stats_nodes)
        stats_layout.addRow("磁盘:", self.stats_disk)
        
        stats_group.setLayout(stats_layout)
        detail_layout.addWidget(stats_group)
        
        # 操作按钮
        action_layout = QHBoxLayout()
        
        edit_btn = QPushButton("✏️ 编辑")
        edit_btn.clicked.connect(self.edit_instance)
        
        delete_btn = QPushButton("🗑️ 删除")
        delete_btn.clicked.connect(self.delete_instance)
        
        action_layout.addWidget(edit_btn)
        action_layout.addWidget(delete_btn)
        action_layout.addStretch()
        
        detail_layout.addLayout(action_layout)
        detail_layout.addStretch()
        
        # 堆叠布局
        self.stacked_layout = QStackedLayout()
        self.stacked_layout.addWidget(self.empty_label)
        self.stacked_layout.addWidget(self.detail_container)
        
        layout.addLayout(self.stacked_layout)
        
        return widget
    
    def refresh_instance_list(self):
        """刷新实例列表"""
        self.instance_list.clear()
        
        if not self.manager.instances:
            self.stacked_layout.setCurrentIndex(0)
            self.statusBar().showMessage("没有实例 - 点击'添加实例'或'智能扫描'开始")
            return
        
        for instance in self.manager.instances:
            item = QListWidgetItem()
            status = "🟢" if self.manager.is_running(instance['id']) else "⚫"
            text = f"{status} [{instance['type']}] {instance['name']}"
            item.setText(text)
            item.setData(Qt.UserRole, instance['id'])
            self.instance_list.addItem(item)
        
        if self.instance_list.count() > 0:
            self.instance_list.setCurrentRow(0)
    
    def on_instance_selected(self, current, previous):
        """实例选中事件"""
        if not current:
            self.stacked_layout.setCurrentIndex(0)
            return
        
        instance_id = current.data(Qt.UserRole)
        self.current_instance_id = instance_id
        self.stacked_layout.setCurrentIndex(1)
        self.update_instance_info(instance_id)
    
    def update_instance_info(self, instance_id):
        """更新实例信息"""
        instance = self.manager.get_instance(instance_id)
        if not instance:
            return
        
        # 基本信息
        self.info_name.setText(instance['name'])
        self.info_type.setText(instance['type'])
        self.info_path.setText(instance['path'])
        self.info_script.setText(instance.get('main_script', 'main.py'))
        
        # 检测Python路径
        path = Path(instance['path'])
        
        # 优先显示用户指定的Python
        specified_python = instance.get('python_path')
        
        if specified_python:
            # 用户指定了Python路径
            if os.path.isabs(specified_python):
                self.info_python.setText(f"🎯 指定 ({specified_python})")
            else:
                self.info_python.setText(f"🎯 指定 ({specified_python})")
            self.info_python.setStyleSheet("color: blue; font-weight: bold;")
        else:
            # 自动检测Python
            python_exe = find_python_executable(path)
            if python_exe == 'python':
                self.info_python.setText("系统Python")
                self.info_python.setStyleSheet("")
            else:
                # 显示相对路径
                try:
                    rel_path = Path(python_exe).relative_to(path)
                    self.info_python.setText(f"✅ 内置 ({rel_path})")
                    self.info_python.setStyleSheet("color: green; font-weight: bold;")
                except:
                    self.info_python.setText(f"内置 ({python_exe})")
                    self.info_python.setStyleSheet("color: green;")
        
        self.info_port.setText(str(instance.get('port', 8188)))
        
        # 运行状态
        is_running = self.manager.is_running(instance_id)
        if is_running:
            self.info_status.setText("🟢 运行中")
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.quick_edit_btn.setEnabled(False)
        else:
            self.info_status.setText("⚫ 未运行")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.quick_edit_btn.setEnabled(True)
        
        # 在后台加载统计信息
        self.load_stats_async(instance)
    
    def load_stats_async(self, instance):
        """异步加载统计信息"""
        if self.stats_worker and self.stats_worker.isRunning():
            self.stats_worker.stop()
            self.stats_worker.wait()
        
        self.stats_models.setText("加载中...")
        self.stats_loras.setText("加载中...")
        self.stats_outputs.setText("加载中...")
        self.stats_nodes.setText("加载中...")
        self.stats_disk.setText("加载中...")
        
        self.stats_worker = StatsWorker(instance)
        self.stats_worker.finished.connect(self.on_stats_loaded)
        self.stats_worker.start()
    
    def on_stats_loaded(self, stats):
        """统计信息加载完成"""
        self.stats_models.setText(str(stats['models']))
        self.stats_loras.setText(str(stats['loras']))
        self.stats_outputs.setText(f"~{stats['outputs']}")
        self.stats_nodes.setText(str(stats['custom_nodes']))
        self.stats_disk.setText(f"~{stats['disk_usage']:.2f} GB")
    
    def update_status(self):
        """定时更新状态"""
        if self.current_instance_id:
            instance = self.manager.get_instance(self.current_instance_id)
            if instance:
                is_running = self.manager.is_running(self.current_instance_id)
                
                if is_running:
                    self.info_status.setText("🟢 运行中")
                    self.start_btn.setEnabled(False)
                    self.stop_btn.setEnabled(True)
                    self.quick_edit_btn.setEnabled(False)
                else:
                    self.info_status.setText("⚫ 未运行")
                    self.start_btn.setEnabled(True)
                    self.stop_btn.setEnabled(False)
                    self.quick_edit_btn.setEnabled(True)
        
        # 更新列表显示
        for i in range(self.instance_list.count()):
            item = self.instance_list.item(i)
            instance_id = item.data(Qt.UserRole)
            instance = self.manager.get_instance(instance_id)
            
            status = "🟢" if self.manager.is_running(instance_id) else "⚫"
            text = f"{status} [{instance['type']}] {instance['name']}"
            item.setText(text)
    
    def start_instance(self):
        """启动实例"""
        if not self.current_instance_id:
            return
        
        success, message = self.manager.start_instance(self.current_instance_id)
        if success:
            self.statusBar().showMessage(message, 5000)
            self.update_instance_info(self.current_instance_id)
        else:
            QMessageBox.warning(self, "启动失败", message)
    
    def stop_instance(self):
        """停止实例"""
        if not self.current_instance_id:
            return
        
        success, message = self.manager.stop_instance(self.current_instance_id)
        if success:
            self.statusBar().showMessage(message, 3000)
            self.update_instance_info(self.current_instance_id)
        else:
            QMessageBox.warning(self, "停止失败", message)
    
    def quick_edit(self):
        """快速编辑"""
        if not self.current_instance_id:
            return
        
        instance = self.manager.get_instance(self.current_instance_id)
        dialog = QuickEditDialog(instance, self)
        
        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()
            self.manager.quick_update(self.current_instance_id, data)
            self.update_instance_info(self.current_instance_id)
            self.statusBar().showMessage("配置已更新", 3000)
    
    def open_browser(self):
        """打开浏览器"""
        if not self.current_instance_id:
            return
        
        instance = self.manager.get_instance(self.current_instance_id)
        port = instance.get('port', 8188)
        url = f"http://127.0.0.1:{port}"
        
        webbrowser.open(url)
        self.statusBar().showMessage(f"已打开浏览器: {url}", 3000)
    
    def open_folder(self, folder_type):
        """打开文件夹"""
        if not self.current_instance_id:
            return
        
        instance = self.manager.get_instance(self.current_instance_id)
        path = Path(instance['path'])
        
        folder_map = {
            'root': path,
            'output': path / 'output' if instance['type'] == 'ComfyUI' else path / 'outputs',
            'lora': path / 'models' / 'loras' if instance['type'] == 'ComfyUI' else path / 'models' / 'Lora',
            'model': path / 'models' / 'checkpoints' if instance['type'] == 'ComfyUI' else path / 'models' / 'Stable-diffusion',
            'node': path / 'custom_nodes' if instance['type'] == 'ComfyUI' else path / 'extensions'
        }
        
        target_path = folder_map.get(folder_type, path)
        
        if not target_path.exists():
            QMessageBox.warning(self, "警告", f"文件夹不存在: {target_path}")
            return
        
        if sys.platform == 'win32':
            os.startfile(str(target_path))
        elif sys.platform == 'darwin':
            subprocess.run(['open', str(target_path)])
        else:
            subprocess.run(['xdg-open', str(target_path)])
        
        self.statusBar().showMessage(f"已打开文件夹: {target_path.name}", 3000)
    
    def add_instance(self):
        """添加实例"""
        dialog = AddInstanceDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()
            if not data['name'] or not data['path']:
                QMessageBox.warning(self, "警告", "名称和路径不能为空")
                return
            
            self.manager.add_instance(data)
            self.refresh_instance_list()
            self.statusBar().showMessage("实例添加成功", 3000)
    
    def edit_instance(self):
        """编辑实例"""
        if not self.current_instance_id:
            return
        
        instance = self.manager.get_instance(self.current_instance_id)
        dialog = AddInstanceDialog(self, instance)
        
        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()
            self.manager.update_instance(self.current_instance_id, data)
            self.refresh_instance_list()
            self.update_instance_info(self.current_instance_id)
            self.statusBar().showMessage("实例更新成功", 3000)
    
    def delete_instance(self):
        """删除实例"""
        if not self.current_instance_id:
            return
        
        instance = self.manager.get_instance(self.current_instance_id)
        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除实例 '{instance['name']}' 吗?\n\n注意: 这只会删除配置,不会删除实际文件。",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.manager.is_running(self.current_instance_id):
                QMessageBox.warning(self, "警告", "请先停止实例再删除")
                return
            
            self.manager.delete_instance(self.current_instance_id)
            self.current_instance_id = None
            self.refresh_instance_list()
            self.statusBar().showMessage("实例删除成功", 3000)
    
    def scan_instances(self):
        """智能扫描实例"""
        path = QFileDialog.getExistingDirectory(self, "选择搜索目录 (可选,留空则搜索常用位置)")
        
        search_paths = [Path(path)] if path else None
        
        self.progress_dialog = QProgressDialog("正在智能扫描实例...", "取消", 0, 0, self)
        self.progress_dialog.setWindowTitle("扫描中")
        self.progress_dialog.setWindowModality(Qt.WindowModal)
        self.progress_dialog.canceled.connect(self.cancel_scan)
        self.progress_dialog.show()
        
        self.scanner = InstanceScanner(search_paths)
        self.scanner.found.connect(lambda inst: self.progress_dialog.setLabelText(f"发现: {inst['name']}"))
        self.scanner.progress.connect(lambda msg: self.progress_dialog.setLabelText(msg))
        self.scanner.finished_scan.connect(self.on_scan_finished)
        self.scanner.start()
    
    def cancel_scan(self):
        """取消扫描"""
        if self.scanner:
            self.scanner.stop()
    
    def on_scan_finished(self, instances):
        """扫描完成"""
        if hasattr(self, 'progress_dialog'):
            self.progress_dialog.close()
        
        if not instances:
            QMessageBox.information(self, "扫描完成", "未找到任何实例")
            return
        
        msg = f"找到 {len(instances)} 个实例:\n\n"
        for inst in instances[:10]:
            msg += f"[{inst['type']}] {inst['name']}\n"
            msg += f"  └ 启动脚本: {inst['main_script']}\n"
        if len(instances) > 10:
            msg += f"\n... 还有 {len(instances) - 10} 个实例"
        
        reply = QMessageBox.question(
            self, "扫描完成",
            msg + "\n\n是否添加这些实例?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            for inst in instances:
                exists = any(i['path'] == inst['path'] for i in self.manager.instances)
                if not exists:
                    self.manager.add_instance(inst)
            
            self.refresh_instance_list()
            self.statusBar().showMessage(f"已添加 {len(instances)} 个实例", 3000)
    
    def show_settings(self):
        """显示设置对话框"""
        dialog = QDialog(self)
        dialog.setWindowTitle("设置")
        dialog.setMinimumWidth(400)
        
        layout = QVBoxLayout()
        
        # 自动打开浏览器
        browser_group = QGroupBox("启动选项")
        browser_layout = QVBoxLayout()
        
        self.auto_browser_check = QCheckBox("启动后自动打开浏览器")
        self.auto_browser_check.setChecked(self.manager.settings.get('auto_open_browser', True))
        browser_layout.addWidget(self.auto_browser_check)
        
        # 延迟设置
        delay_layout = QHBoxLayout()
        delay_label = QLabel("浏览器打开延迟（秒）:")
        self.delay_spin = QSpinBox()
        self.delay_spin.setRange(0, 30)
        self.delay_spin.setValue(self.manager.settings.get('browser_delay', 3))
        self.delay_spin.setEnabled(self.auto_browser_check.isChecked())
        
        # 连接信号
        self.auto_browser_check.toggled.connect(self.delay_spin.setEnabled)
        
        delay_layout.addWidget(delay_label)
        delay_layout.addWidget(self.delay_spin)
        delay_layout.addStretch()
        
        browser_layout.addLayout(delay_layout)
        
        hint = QLabel("💡 建议延迟3-5秒，给服务足够的启动时间")
        hint.setStyleSheet("color: gray;")
        browser_layout.addWidget(hint)
        
        browser_group.setLayout(browser_layout)
        layout.addWidget(browser_group)
        
        # 按钮
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("保存")
        save_btn.clicked.connect(lambda: self.save_settings(dialog))
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(dialog.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        
        layout.addLayout(btn_layout)
        dialog.setLayout(layout)
        dialog.exec_()
    
    def save_settings(self, dialog):
        """保存设置"""
        self.manager.settings['auto_open_browser'] = self.auto_browser_check.isChecked()
        self.manager.settings['browser_delay'] = self.delay_spin.value()
        self.manager.save_config()
        
        self.statusBar().showMessage("设置已保存", 3000)
        dialog.accept()
    
    def closeEvent(self, event):
        """关闭事件"""
        if self.stats_worker and self.stats_worker.isRunning():
            self.stats_worker.stop()
            self.stats_worker.wait()
        
        if self.scanner and self.scanner.isRunning():
            self.scanner.stop()
            self.scanner.wait()
        
        running = [inst['id'] for inst in self.manager.instances if self.manager.is_running(inst['id'])]
        
        if running:
            reply = QMessageBox.question(
                self, "退出确认",
                f"还有 {len(running)} 个实例正在运行,确定要退出吗?\n\n退出后实例将继续在后台运行。",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.No:
                event.ignore()
                return
        
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()